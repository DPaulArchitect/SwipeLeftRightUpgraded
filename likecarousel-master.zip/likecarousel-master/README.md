# likecarousel

Build a Full Featured "Like Carousel" in Vanilla JavaScript

[Read full article on Medium](https://medium.com/@simonepm/build-a-full-featured-tinder-like-carousel-in-vanilla-javascript-part-i-44ca3a906450)

[Read full article on Hackdoor](https://www.hackdoor.io/articles/8MNPqDpV/build-full-featured-tinder-carousel-vanilla-javascript)

**View final result on YouTube:**

[<img src="https://github.com/simonepm/likecarousel/raw/master/thumbnail.png" width="250">](https://www.youtube.com/watch?v=ociKlTBEO5Q)
